import { connectWebSocket } from "../binance/websocket.js";
import { updateLiquidation } from "./store.js";

const SUBSCRIBE_DELAY_MS = 250;

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function subscribeToLiquidations(symbols: string[]) {
  const connection = await connectWebSocket();

  type LiquidationRequest = Parameters<
    typeof connection.liquidationOrderStreams
  >[0];

  console.log(`[liquidations] Subscribing ${symbols.length} symbols`);

  for (const [index, symbol] of symbols.entries()) {
    const stream = connection.liquidationOrderStreams({
      symbol,
    } as LiquidationRequest);

    stream.on("message", (message) => {
      if (!message) {
        return;
      }
      // console.log("[liquidation event]", message);

      const order = message.o;

      if (!order) {
        return;
      }

      const price = Number(order.p);
      const quantity = Number(order.q);

      updateLiquidation({
        symbol: order.s!,
        side: order.S === "BUY" ? "SHORT" : "LONG",
        price,
        quantity,
        notional: price * quantity,
        eventTime: Number(message.E),
      });
    });

    if ((index + 1) % 20 === 0 || index === symbols.length - 1) {
      console.log(`[liquidations] Subscribed ${index + 1}/${symbols.length}`);
    }

    await sleep(SUBSCRIBE_DELAY_MS);
  }

  console.log("[liquidations] Subscription setup completed");

  return connection;
}
