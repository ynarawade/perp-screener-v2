export interface OiSample {
  timestamp: number;
  openInterest: number;
}

export interface RealtimeMarketState {
  markPrice: number | null;
  fundingRate: number | null;
  nextFundingTime: number | null;

  priceUpdatedAt: number | null;
  fundingUpdatedAt: number | null;
}

export interface SymbolMarketState {
  symbol: string;

  realtime: RealtimeMarketState;

  klines: unknown[];
  klinesUpdatedAt: number | null;

  oiSamples: OiSample[];
  oiUpdatedAt: number | null;
}

export type MarkPriceData = {
  symbol: string;
  markPrice: number;
  indexPrice: number;
  fundingRate: number;
  nextFundingTime: number;
  eventTime: number;
};

export type TickerData = {
  symbol: string;
  priceChange: number;
  priceChangePercent: number;
  lastPrice: number;
  volume: number;
  quoteVolume: number;
  eventTime: number;
};

export type KlineInterval = "1m" | "5m" | "15m" | "1h";

export type KlineData = {
  symbol: string;
  interval: KlineInterval;

  openTime: number;
  closeTime: number;

  open: number;
  high: number;
  low: number;
  close: number;

  volume: number;
  quoteVolume: number;

  closed: boolean;

  eventTime: number;
};

export type MarketData = MarkPriceData &
  TickerData & {
    klines: Record<KlineInterval, KlineData[]>;
  };
