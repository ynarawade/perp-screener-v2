import type {
  KlineData,
  MarketData,
  MarkPriceData,
  TickerData,
} from "./types.js";

const marketData = new Map<string, MarketData>();

export function updateMarkPrice(data: MarkPriceData) {
  const existing = marketData.get(data.symbol);

  marketData.set(data.symbol, {
    ...existing,
    ...data,
  } as MarketData);
}

export function updateTicker(data: TickerData) {
  const existing = marketData.get(data.symbol);

  marketData.set(data.symbol, {
    ...existing,
    ...data,
  } as MarketData);
}

export function updateKline(data: KlineData) {
  const existing = marketData.get(data.symbol);

  if (!existing) {
    return;
  }

  const candles = existing.klines[data.interval] ?? [];

  const existingIndex = candles.findIndex(
    (kline) => kline.openTime === data.openTime
  );

  let updatedCandles: KlineData[];

  if (existingIndex !== -1) {
    updatedCandles = [...candles];
    updatedCandles[existingIndex] = data;
  } else {
    updatedCandles = [...candles, data];
  }

  updatedCandles = updatedCandles.slice(-120);

  marketData.set(data.symbol, {
    ...existing,
    klines: {
      ...existing.klines,
      [data.interval]: updatedCandles,
    },
  });
}

export function getMarketData(symbol: string) {
  return marketData.get(symbol);
}

export function getAllMarketData() {
  return Array.from(marketData.values());
}
