import { connectWebSocket } from "../binance/websocket.js";
import type { KlineData, KlineInterval } from "./types.js";

const intervals: KlineInterval[] = ["1m", "5m", "15m", "1h"];

export async function subscribeToKlines(
  symbols: string[],
  onUpdate: (data: KlineData) => void
) {
  const connection = await connectWebSocket();

  for (const interval of intervals) {
    for (const symbol of symbols) {
      const stream = connection.klineCandlestickStreams({
        symbol,
        interval,
      });

      stream.on("message", (message) => {
        if (!message) {
          return;
        }

        const kline = message.k;

        if (!kline) {
          return;
        }

        onUpdate({
          symbol: kline.s,
          interval: kline.i as KlineInterval,

          openTime: Number(kline.t),
          closeTime: Number(kline.T),

          open: Number(kline.o),
          high: Number(kline.h),
          low: Number(kline.l),
          close: Number(kline.c),

          volume: Number(kline.v),
          quoteVolume: Number(kline.q),

          closed: Boolean(kline.x),

          eventTime: Number(message.E),
        });
      });
    }
  }

  return connection;
}
